package testingg;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import coalBase.BaseMethods;

public class Testing extends BaseMethods
{
	@Test(priority=1)
	public void testinggg() throws Exception
	{
		startApplication("Chrome");
		Thread.sleep(2000);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Product | Family | Group')]")).click();		
	}
	
	public void ProductName() throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-250)", "");
		Thread.sleep(5000);
		//Name
  	     driver.findElement(By.xpath("//*[@id=\"productGrid\"]/div[1]/a")).click();
  	     Thread.sleep(1000);
  	     driver.findElement(By.xpath("//input[@id='ProductName']")).sendKeys("Product");
  	     Thread.sleep(2000);
	}
	public void ProductShortName(String data2) throws Exception
	{
		driver.findElement(By.xpath("//input[@id='ProductShortName']")).sendKeys("SN");
		Thread.sleep(2000);
	}
	public void Productdescription(String data3) throws Exception
	{
		driver.findElement(By.xpath("//input[@id='ProductDescription']")).sendKeys("Des");
		Thread.sleep(2000);
	}
	/*click(WebElement ele)
	type(WebElement ele, String data)
	WebElement locateElement(String locator, String locValue)*/
		
}
