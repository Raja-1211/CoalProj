package coalAdminPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import adminTestCases.TC_05;
import adminTestCases.TC_06;
import coalBase.BaseMethods;

public class MRCompOpr extends BaseMethods
{

	public MRCompOpr(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void MROperations(String data2) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='autoOperation']")).sendKeys(data2);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='autoOperation_listbox']/li[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='btnOpertation']")).click();
    }
	
	public void autoComponent(String data3) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='autoComponent']")).sendKeys(data3);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='autoComponent_listbox']/li[1]")).click();
		/*driver.findElement(By.xpath("//input[@id='numQty']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='numQty']")).sendKeys("");*/
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnComponents']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();	
	}

	public Routing RoutingAdmin() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[contains(text(),'Routing')]")).click();
		return new Routing(driver);
	}
}
