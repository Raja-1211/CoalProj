package coalAdminPages;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import adminTestCases.TC_01;
import adminTestCases.TC_03;
import coalBase.BaseMethods;

/**
 * This class contains the Methods to add the Customer, Currency, Region, Country, UoM and Divison
 * @author Raja & Babu
 */

public class BaseMaster
{		
	
	/**
	 * This method will pass the Customer name in the Customer text field
	 * @param customername - This will pass the Customer Name data 
	 * @throws NullPointerException 
	 * @author Raja
	 * @throws InterruptedException 
	 */
	
	WebDriver driver;
	
	public BaseMaster(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}	
		
	public void createCustomername(String data1) throws InterruptedException 
		{
			Thread.sleep(3000);
		    driver.findElement(By.xpath("//*[@id=\"customerGrid\"]/div[1]/a")).click();
		    Thread.sleep(1000);	
			driver.findElement(By.xpath("//input[@class='text-box single-line' and @id='Name']")).sendKeys(data1);
		}
	
	/**
	 * This method will pass the Customer Short Name in the Customer text field
	 * @param customersnname - This will pass the Customer Short Name data 
	 * @throws NullPointerException
	 * @author Raja
	 * @throws InterruptedException 
	 */
	
	public void createCustomersnname(String data2) throws InterruptedException 
	{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@class='text-box single-line' and @id='ShortName']")).sendKeys(data2);
	}
	
	public void createCustomerCategory(String data3) throws InterruptedException 
	{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//span[@aria-owns='CategoryName_listbox' ]")).click();
			Thread.sleep(2000);
			if(data3.equalsIgnoreCase("External"))
			{
			driver.findElement(By.xpath("//li[contains(text(),'External')]")).click();
			}else
			{
			driver.findElement(By.xpath("//li[contains(text(),'Internal')]")).click();
			}
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='customerGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
			Thread.sleep(2000);
	}
	
	/** This method will click the Filter icon and pass the newly created Customer Name. 
	 * This method will link the Newly created Customer Data with the Division
	 * @throws Exception
	 * @author Raja
	 */
	
	public void customerFilter(){
		try {
			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[@role='button' and @class='k-button k-button-icontext k-primary k-grid-update']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='customerGrid']/div[2]/div/table/thead/tr/th[7]/a[1]/span")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[@type='reset' and @class='k-button']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='customerGrid']/div[2]/div/table/thead/tr/th[7]/a[1]/span")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@class='k-textbox' and @title='Value']")).sendKeys("Customer-Sticky Coal");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[text()='Filter']")).click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='customerGrid']/div[3]/table/tbody/tr/td[5]/a")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='CustomerDivisionGrid']/div[1]/a")).click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='CustomerDivisionGrid']/div[3]/table/tbody/tr/td[7]/span[1]/span/span[2]/span")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'3M IPC')]")).click();
			Thread.sleep(2000);
			} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/** This method will create the data in the Currency section
	 * @throws Exception
	 * @author Raja
	 */
	
	public void createCurrencyName(String data1)throws Exception
	{		
		Thread.sleep(4000);
		//Add Button
		driver.findElement(By.xpath("//*[@id='MasterCurrencyGrid']/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='text-box single-line' and @name='Name']")).sendKeys(data1);
		Thread.sleep(2000);
		}
		
	public void createCurrencySName(String data2)throws Exception
	{
	 driver.findElement(By.xpath("//input[@id='Description']")).sendKeys(data2);
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//a[@class='k-button k-button-icontext k-primary k-grid-update']")).click();
	 Thread.sleep(2000);
	} 
	
	/**
	 * This method will create the data in the Region section
	 * @throws Exception
	 * @author Raja
	 */
	
	public void createRegionName(String data1)throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(4000);
		//Add button		
		driver.findElement(By.xpath("//*[@id='MasterRegionGrid']/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='text-box single-line' and @name='Name']")).sendKeys(data1);
		Thread.sleep(2000);
	}
	
	public void createRegionSName(String data2)throws Exception
	{
		driver.findElement(By.xpath("//input[@class='text-box single-line' and @name='Description']")).sendKeys(data2);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='k-button k-button-icontext k-primary k-grid-update']")).click();
		Thread.sleep(2000);	
	}
	
	/**
	 * This method will create the new Country in the Country section
	 * @throws Exception
	 * @author Babu
	 */
	
	 public void createCountryName(String data1) throws Exception
	 {
		 //Add Button		
		 driver.findElement(By.xpath("//*[@id=\"GridCountry\"]/div[1]/a")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id='Name']")).sendKeys(data1);
		 Thread.sleep(2000);
	 }
	 
	 public void createCountrySName(String data2) throws Exception
	 {
	 	driver.findElement(By.xpath("//input[@id='Code']")).sendKeys(data2);
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		WebElement servicedesk= driver.findElement(By.xpath(" //*[@id='GridCountry']/div[3]/table/tbody/tr[1]/td[7]/span[1]/span/span[2]/span"));
		action.moveToElement(servicedesk).click().build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'ASIA')]")).click();
		Thread.sleep(2000);
	 }
	 
	 public void createCountryLatitude(String data3) throws Exception
	 {
	 
		driver.findElement(By.xpath(" //input[@id='Latitude']")).sendKeys(data3);
		Thread.sleep(2000);
	 }
	 public void createCountryLongitude(String data4) throws Exception
	 {
		driver.findElement(By.xpath(" //input[@id='Longitude']")).sendKeys(data4);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='GridCountry']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
		Thread.sleep(2000);
	} 
	 
	 /**
		 * This method will create the new data in the UoM section
		 * @throws Exception
		 * @author Babu
		 */

	public void createUoMName(String data1) throws Exception
	{
		 //Add button		
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"UoMGrid\"]/div[1]/a")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
	}
	
	public void createUoMCode(String data2) throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Code']")).sendKeys(data2);
	}
	
	public void createUoMDescription(String data3) throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Description']")).sendKeys(data3);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='UoMGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[contains(text(),'Product | Family | Group')]")).click();	
		Thread.sleep(3000);		
		
	} 
	
	 /**
	 * This method will link the Customer, Product and Work Center with the Division
	 * @throws Exception
	 * @author Babu
	 * @return 
	 */
	 
    public void DivisionCustomer(String data1) throws Exception
    {  	
    	//Customer
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//*[@id='DivisionGrid']/div[3]/table/tbody/tr[2]/td[2]/a")).click();
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//*[@id=\"DivisionCustomerGrid\"]/div[1]/a")).click();
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//*[@id='DivisionCustomerGrid']/div[3]/table/tbody/tr[1]/td[6]/span[1]/span/span[2]/span")).click();
  		Thread.sleep(4000);
  		if(data1.equalsIgnoreCase("CIT Customer1"))
		{
  			Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='CustomerID_listbox']/li[79]")).click();
		}else
		{
		driver.findElement(By.xpath("//*[@id='CustomerID_listbox']/li[76]")).click();
		}
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//*[@id='DivisionCustomerGrid']/div[3]/table/tbody/tr/td[1]/a[1]/span")).click();
  		Thread.sleep(3000);
  		driver.findElement(By.xpath("//button[@id='btnBack']n")).click();
  		Thread.sleep(4000);
  	
    }
    
    public void DivisionProduct(String data2) throws Exception
    { 
  		//Product
  		driver.findElement(By.xpath("//*[@id='DivisionGrid']/div[3]/table/tbody/tr[1]/td[3]/a")).click();
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//*[@id='DivisionProductMapGrid']/div[1]/a")).click();
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//*[@id='DivisionProductMapGrid']/div[3]/table/tbody/tr[1]/td[6]/span[1]/span/span[2]/span")).click();
  		Thread.sleep(4000);
  		if(data2.equalsIgnoreCase("Tape Roll 0.5 x 60"))
		{
		driver.findElement(By.xpath("//*[@id='065dd73b-186d-4211-8e30-b2aff99f9395']")).click();
		}else
		{
		driver.findElement(By.xpath("//*[@id='ProductID_listbox']/li[2034]")).click();
		}
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//*[@id='DivisionProductMapGrid']/div[3]/table/tbody/tr[1]/td[1]/a[1]/span")).click();
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//button[@id='btnBack']n")).click();
  		Thread.sleep(4000);
    }
    public void DivisionWorkCenter(String data3) throws Exception
    { 
  		//WorkCenter
  		driver.findElement(By.xpath("//*[@id='DivisionGrid']/div[3]/table/tbody/tr[2]/td[4]/a")).click();
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//*[@id='DivisionWorkCenterGrid']/div[1]/a")).click();
  		Thread.sleep(4000);
  		driver.findElement(By.xpath("//*[@id='DivisionWorkCenterGrid']/div[3]/table/tbody/tr/td[6]/span[1]/span/span[2]/span")).click();
  		Thread.sleep(4000);
  		if(data3.equalsIgnoreCase("Asia Converting"))
		{
		driver.findElement(By.xpath("//*[@id='WorkCenterID_listbox']/li[43]")).click();
		}else
		{
		driver.findElement(By.xpath("//*[@id='WorkCenterID_listbox']/li[44]")).click();
		}
  		Thread.sleep(3000);
  		driver.findElement(By.xpath("//button[@id='btnBack']n")).click();
  		Thread.sleep(4000);
    }
  		
  		/*FileInputStream fis = new FileInputStream(new File("D:\\3MCoal\\3MCoal\\ExcelData\\DataExcelImport.xlsx"));
  		XSSFWorkbook wb = new XSSFWorkbook(fis);
  		XSSFSheet ws = wb.getSheetAt(5);
  		XSSFSheet ws1 = wb.getSheetAt(6);
  		int RowCount = ws.getLastRowNum()+1;
  		int ColumnCount = ws.getRow(0).getLastCellNum();
  		
  		label:
  		for(int k=2; k<RowCount; k++)
  		{
  			int z=0;
  		XSSFRow Row = ws.getRow(k);
  		XSSFCell cell = Row.getCell(z);
  		String cellValue = cell.toString();
  		System.out.println(cellValue);
  		
  		    int RowCount1 = ws1.getLastRowNum()+1;
  		    System.out.println("Second Sheet Row Count"+RowCount1);
  		    for(int j=2;j<RowCount1;j++)
  		    {
  		   	int zz=1;
  		      XSSFRow Row1 = ws1.getRow(j);
  		      XSSFCell cell1 = Row1.getCell(zz);
  		      String cellValue1 = cell1.toString();
  		      System.out.println(cellValue1);
  		   	if(cellValue.equals(cellValue1))
  		      		{
  		       		WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupID_listbox']"));
  		       		List<WebElement> options = test.findElements(By.tagName("li"));
  		      			for (WebElement opt : options) 
  		      			{
  		      				if (opt.getText().equals(cellValue)) 
  		      				{
  		      					opt.click();
  		      					break label;
  		      				}
  		      			}
  		      		}
  		      	zz++;
  		        }
  		    z++;
  		}*/
  		
    
    /**
 	 * This method will click the ProductFamilyGroup link in the Header
 	 * @author Raja
 	 */
 	
    public BaseMaster adminProductFamilyGroup() 
 	{
 		driver.findElement(By.xpath("//a[contains(text(),'Product | Family | Group')]")).click();
 		return this;
 	}
	
}
	
	