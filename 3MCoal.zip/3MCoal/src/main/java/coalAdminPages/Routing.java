package coalAdminPages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import coalBase.BaseMethods;

public class Routing extends BaseMethods
{
	public Routing(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void routingAddbtn() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='divRouting']/div[1]/div/a")).click();
	}
	
	public void routeName(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='Name']")).sendKeys(data1);
	}
	
	public void routeProduct(String data2) throws InterruptedException, Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='txtModelRouteFinishedGood']")).sendKeys(data2);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='txtModelRouteFinishedGood_listbox']/li[2]")).click();
		
		FileInputStream fis = new FileInputStream(new File("D:\\3MCoal\\3MCoal\\ExcelData\\DataExcelImport.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet ws = wb.getSheetAt(6);
		XSSFSheet ws1 = wb.getSheetAt(7);
		int RowCount = ws.getLastRowNum()+1;
		int ColumnCount = ws.getRow(0).getLastCellNum();
		
		label:
		for(int k=2; k<RowCount; k++)
		{
			int z=0;
		XSSFRow Row = ws.getRow(k);
		XSSFCell cell = Row.getCell(z);
		String cellValue = cell.toString();
		System.out.println(cellValue);
		
		    int RowCount1 = ws1.getLastRowNum()+1;
		    System.out.println("Second Sheet Row Count"+RowCount1);
		    for(int j=2;j<RowCount1;j++)
		    {
		   	int zz=2;
		      XSSFRow Row1 = ws1.getRow(j);
		      XSSFCell cell1 = Row1.getCell(zz);
		      String cellValue1 = cell1.toString();
		      System.out.println(cellValue1);
		   	if(cellValue.equals(cellValue1))
		      		{
		       		WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupID_listbox']"));
		       		List<WebElement> options = test.findElements(By.tagName("li"));
		      			for (WebElement opt : options) 
		      			{
		      				if (opt.getText().equals(cellValue)) 
		      				{
		      					opt.click();
		      					break label;
		      				}
		      			}
		      		}
		      	zz++;
		        }
		    z++;
          }
		
		/*if(data2.equalsIgnoreCase("Product"))
		{
		driver.findElement(By.xpath("//input[@id='rbProduct']")).click();
		driver.findElement(By.xpath("//input[@id='txtModelRouteFinishedGood']")).sendKeys("Granule MSC");
		}
		else if(data2.equalsIgnoreCase("Product Family"))
		{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@id='rbProductFamily']")).click();
			driver.findElement(By.xpath("//input[@name='AutoProductFamily']")).sendKeys("Granule MSC");
		}*/
	}
	
	public void routeStatus(String data3) throws InterruptedException
	{
		Thread.sleep(2000);
		if(data3.equalsIgnoreCase("Active"))
		{
		Select active = new Select(driver.findElement(By.xpath("//*[@id='Status']")));
		active.selectByVisibleText("Active");
		}
		else if(data3.equalsIgnoreCase("InActive"))
		{
			Select inactive = new Select(driver.findElement(By.xpath("//*[@id='Status']")));
			inactive.selectByVisibleText("InActive");
		}
		else if(data3.equalsIgnoreCase("InProgress"))
		{
			Select inprogress = new Select(driver.findElement(By.xpath("//*[@id='Status']")));
			inprogress.selectByVisibleText("InProgress");
		}
	}
	
	public void isTemplate(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		if(data1.equalsIgnoreCase("yes"))
		{
			driver.findElement(By.xpath("//input[@id='IsTemplate']")).click();
		}else if(data1.equalsIgnoreCase("No"))
		{
		}
	}
	
	public void needFocusFactory(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		if(data1.equalsIgnoreCase("yes"))
		{
			driver.findElement(By.xpath("//input[@id='IsFocusFactoryNeeded']")).click();
		}else if(data1.equalsIgnoreCase("No"))
		{	
		}
	}
	
	public void saveButton() throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	}
	
	public void cancelbutton() throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnCancel']")).click();
	}
	
	public void expandAll() throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='NextOperationID']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='NextOperationID']/option[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='Check_14_14_0_1264']")).click();
		Thread.sleep(2000);
		/*driver.findElement(By.xpath("//*[@id='NextOperationID']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='NextOperationID']/option[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='Check_186_186_0_3979']")).click();*/
		//save
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	}
	
	public CreateModel RoutingModel() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[contains(text(),'Routing')]")).click();
		return new CreateModel(driver);
	}
	
}
