package coalAdminPages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminTestCases.TC_04;
import coalBase.BaseMethods;



public class ProductFamilyGroup extends BaseMethods
{
	private WebDriver driver;

	/**
	 * This method will initialize the web elements which are defined in Page Objects
	 * @author Raja
	 */
	public ProductFamilyGroup(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * These methods will create the new Product Group with the Product Group Name and UoM
	 * @throws Exception
	 * @author Raja
	 * @throws InterruptedException 
	 */	
 
	public void productGroupadd() throws InterruptedException
	{
		//Product Group Name
		Thread.sleep(3000);
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(3000);
	    //Add Button
        driver.findElement(By.xpath("//*[@id=\"productGroupGrid\"]/div[1]/a")).click();
	}
	
   public void productGroupName(String data1) throws InterruptedException
	{
	   Thread.sleep(3000);
	 	driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
	}
	
	public void productGroupUoM(String data2) throws Exception
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[3]/table/tbody/tr[1]/td[6]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		readInput("UoM","UoM Name");
		List<String> outputValue=new ArrayList<String>();	
		outputValue=verify("UoM","UoM Name","Product Family Group", "UoM");
		
		Thread.sleep(2000);
		WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupUnitOfMeasurementID_listbox']"));
	   	List<WebElement> options = test.findElements(By.tagName("li"));
	   	for(int n=0;n<outputValue.size();n++) {
	   	String cellValue=outputValue.get(n);
	  		for (WebElement opt : options) 
	  		{
	  			if (opt.getText().equals(cellValue)) 
	  			{
	  				opt.click();
	  				driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	  				break;
	  			}
	  		}
	   }		
	}
	
	/**
	 * These methods will create the new Product Family with the Product Family Name, UoM and linking the Product Group
	 * @throws Exception
	 * @author Raja
	 * @throws InterruptedException 
	 */	
    
	public void productFamilyadd() throws InterruptedException
	{
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[1]/a")).click();
	}
 
	public void productFamilyName(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
	 	driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
	}	
	
 	public void productFamilyUoM(String data2) throws Exception
	{
 		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[8]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		readInput("Product Family Group","Product Group Name");
		List<String> outputValue=new ArrayList<String>();	
		outputValue=verify("Product Family Group","Product Group Name","Product Family", "Product Group");
		
		Thread.sleep(2000);
		WebElement test = driver.findElement(By.xpath(" //*[@id='ProductGroupID_listbox']"));
	   	List<WebElement> options = test.findElements(By.tagName("li"));
	   	for(int n=0;n<outputValue.size();n++) {
	   	String cellValue=outputValue.get(n);
	  		for (WebElement opt : options) 
	  		{
	  			if (opt.getText().equals(cellValue)) 
	  			{
	  				opt.click();
	  				
	  				break;
	  			}
	  		}
	   }	
	}
	
  	public void productFamilyGroup(String data3) throws Exception
	{
		 //Product Family Name
  		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[7]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		readInput("UoM","UoM Name");
		List<String> outputValue=new ArrayList<String>();	
		outputValue=verify("UoM","UoM Name","Product Family", "UoM");
		
		Thread.sleep(2000);
		WebElement test = driver.findElement(By.xpath("//*[@id='UOMID_listbox']"));
	   	List<WebElement> options = test.findElements(By.tagName("li"));
	   	for(int n=0;n<outputValue.size();n++) {
	   	String cellValue=outputValue.get(n);
	  		for (WebElement opt : options) 
	  		{
	  			if (opt.getText().equals(cellValue)) 
	  			{
	  				opt.click();
	  				driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	  				break;
	  			}
	  		}
	   }		
}
  	
  	public void productFamilyselect()
  	{
		driver.findElement(By.xpath("//*[@id=\"productFamilyGrid\"]/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
	/**
	 * This method will create the new Product by passing the Product Name, SN, Currency, Product Family, Product Category, 10digit SAP, 11 digit legacy, On Hand Quantiy, Storage, Transportation and Testing data 
	 * @throws Exception
	 * @author Raja
	 */	
	
	public void ProductName(String data1) throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-250)", "");
		Thread.sleep(5000);
		//Name
  	     driver.findElement(By.xpath("//*[@id=\"productGrid\"]/div[1]/a")).click();
  	     Thread.sleep(1000);
  	     driver.findElement(By.xpath("//input[@id='ProductName']")).sendKeys(data1);
  	     Thread.sleep(2000);
	}
	public void ProductShortName(String data2) throws Exception
	{
		driver.findElement(By.xpath("//input[@id='ProductShortName']")).sendKeys(data2);
		Thread.sleep(2000);
	}
	public void Productdescription(String data3) throws Exception
	{
		driver.findElement(By.xpath("//input[@id='ProductDescription']")).sendKeys(data3);
		Thread.sleep(2000);
	}
		//UOM
	public void ProductUoM(String data4) throws Exception
	{
		 //Product Family Name
  		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='productGrid']/div[4]/table/tbody/tr[1]/td[4]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		readInput("UoM","UoM Name");
		List<String> outputValue=new ArrayList<String>();	
		outputValue=verify("UoM","UoM Name","Product", "UoM");
		
		Thread.sleep(2000);
		WebElement test = driver.findElement(By.xpath("//*[@id='ProductUnitOfMeasurementID_listbox']"));
	   	List<WebElement> options = test.findElements(By.tagName("li"));
	   	for(int n=0;n<outputValue.size();n++) {
	   	String cellValue=outputValue.get(n);
	  		for (WebElement opt : options) 
	  		{
	  			if (opt.getText().equals(cellValue)) 
	  			{
	  				opt.click();
	  				break;
	  			}
	  		}
	   }		
	}
		//Currency
	public void ProductCurrency(String data5) throws Exception
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='productGrid']/div[4]/table/tbody/tr[1]/td[4]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		readInput("Currency","Currency Name");
		List<String> outputValue=new ArrayList<String>();	
		outputValue=verify("Currency","Currency Name","Product","Currency");
		
		Thread.sleep(2000);
		WebElement test = driver.findElement(By.xpath("//*[@id='ProductUnitOfMeasurementID_listbox']"));
		
	   	List<WebElement> options = test.findElements(By.tagName("li"));
	   	for(int n=0;n<outputValue.size();n++) {
	   	String cellValue=outputValue.get(n);
	  		for (WebElement opt : options) 
	  		{
	  			if (opt.getText().equals(cellValue)) 
	  			{
	  				opt.click();
	  				break;
	  			}
	  		}
	   }		
	}
		//Product Family
	public void Productfam(String data6) throws Exception
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='productGrid']/div[4]/table/tbody/tr[1]/td[6]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		readInput("Product Family","Product Family Name");
		List<String> outputValue=new ArrayList<String>();	
		outputValue=verify("Product Family","Product Family Name","Product","Product Family");
		
		Thread.sleep(2000);
		WebElement test = driver.findElement(By.xpath("//*[@id='ProductFamilyID_listbox']"));
		
	   	List<WebElement> options = test.findElements(By.tagName("li"));
	   	for(int n=0;n<outputValue.size();n++) {
	   	String cellValue=outputValue.get(n);
	  		for (WebElement opt : options) 
	  		{
	  			if (opt.getText().equals(cellValue)) 
	  			{
	  				opt.click();
	  				driver.findElement(By.xpath("//*[@id='productGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();	  			
	  				break;
	  			}
	  		}
	   }		
	}
		//Product Category
	public void ProductCategory(String data7) throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productGrid']/div[3]/table/tbody/tr[1]/td[13]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data7.equalsIgnoreCase("Finished Good"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Finished Good')]")).click();
		}else if(data7.equalsIgnoreCase("Semi-Finished Good"))
		{
			driver.findElement(By.xpath("//li[contains(text(),'Semi-Finished Good')]")).click();
		}else if(data7.equalsIgnoreCase("Raw Material"))
		{
			driver.findElement(By.xpath("//li[contains(text(),'Raw Material')]")).click();
		}
		Thread.sleep(2000);
	}
	public void ProductSAP(String data8) throws Exception
	{
		//10 digit SAP
		driver.findElement(By.xpath("//input[@id='TenDigitSAPNumber']")).sendKeys(data8);
		Thread.sleep(2000);
	}
	public void Productlegacy(String data9) throws Exception
	{
		//11 digit Legacy
		driver.findElement(By.xpath("//input[@id='ElevenDigitSAPNumber']")).sendKeys(data9);
		Thread.sleep(2000);
	}
	public void ProductOnHandQuantity(String data10) throws Exception
	{
		//On Hand Quantiy
		driver.findElement(By.xpath("//input[@id='CurrentOnHandQuantity']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='CurrentOnHandQuantity']")).sendKeys(data10);
		Thread.sleep(2000);
	}
	public void ProductStorage(String data11) throws Exception
	{
		//Storage
		driver.findElement(By.xpath("//input[@id='Storage']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Storage']")).sendKeys(data11);
		Thread.sleep(2000);
	}
	public void ProductTransportation(String data12) throws Exception
	{
		//Transportation
		driver.findElement(By.xpath("//input[@id='Transportation']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Transportation']")).sendKeys(data12);
		Thread.sleep(2000);
	}
	public void ProductTesting(String data13) throws Exception
	{
		//Testing
		driver.findElement(By.xpath("//input[@id='Testing']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Testing']")).sendKeys(data13);
		Thread.sleep(2000);
	}
	
	public void ProductIsPhantom() throws Exception
	{	
		//IsPhantom
		driver.findElement(By.xpath("//input[@id='IsPhantom']")).click();
		Thread.sleep(2000);
		//Tick Mark
		driver.findElement(By.xpath("//*[@id='productGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
		Thread.sleep(2000);	
	}	
	
	/**
	 * This method will navigate to the Operation Work Center page from the Product Family Group page
	 * @throws Exception
	 * @author Raja
	 */	
	
	public OperationWorkCenter operationWc()
	{
		driver.findElement(By.xpath("//a[contains(text(),'Operation Work Center')]")).click();
		return new OperationWorkCenter(driver);
	}
	
}


