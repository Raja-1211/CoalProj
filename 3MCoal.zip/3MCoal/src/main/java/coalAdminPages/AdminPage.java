package coalAdminPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import adminTestCases.TC_02;
import coalBase.BaseMethods;

/**
 * This class contains the Methods to click the Admin and BaseMaster link under the Admin section
 * @author Raja
 */

public class AdminPage extends BaseMethods
{
	WebDriver driver;
	/**
	 * This method will initialize the web elements which are defined in Page Objects
	 * @author Raja
	 */
	
	public AdminPage(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * This method will click the AdminPage link in the Header
	 * @author Raja
	 */

	
	@FindBy(how=How.XPATH, using="//i[@class='fa fa-user fa-lg']")
	public WebElement admin;
	public AdminPage adminmainpage() throws Exception 
	{
		admin.click();
		return this;
	}
	
	/**
	 * This method will click the BaseMaster link in the Header
	 * @author Raja
	 */
	
	/*@FindBy(how=How.XPATH, using="//a[text()='Base Master']")
	public WebElement adminbm;
	public BaseMaster adminBaseMaster() 
	{
		adminbm.click();
		return new BaseMaster(driver);
	}*/
	
	@FindBy(how=How.XPATH, using="//a[text()='Base Master']")
	public WebElement adminbm;
	public AdminPage adminBaseMaster() 
	{
		adminbm.click();
		return this;
	}	
}

