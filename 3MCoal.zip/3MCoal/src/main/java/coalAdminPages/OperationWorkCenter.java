package coalAdminPages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminTestCases.TC_05;
import coalBase.BaseMethods;

public class OperationWorkCenter extends BaseMethods
{
	public WebDriver driver;
	
	public OperationWorkCenter(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void operationName(String data1) throws InterruptedException
	{
		//Add button
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[1]/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='Name']")).sendKeys(data1);
		Thread.sleep(1000);
	}
	
	public void operationSName(String data2) throws InterruptedException
	{
		driver.findElement(By.xpath("//input[@id='ShortName']")).sendKeys(data2);
		Thread.sleep(1000);
	}
	public void operationRegion(String data3) throws InterruptedException, Exception
	{
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[8]/span[1]/span/span[2]/span")).click();
		Thread.sleep(1000);
		FileInputStream fis = new FileInputStream(new File("D:\\3MCoal\\3MCoal\\ExcelData\\DataExcelImport.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet ws = wb.getSheetAt(3);
		XSSFSheet ws1 = wb.getSheetAt(9);
		int RowCount = ws.getLastRowNum()+1;
		int ColumnCount = ws.getRow(0).getLastCellNum();
		
		label:
		for(int k=2; k<RowCount; k++)
		{
			int z=0;
		XSSFRow Row = ws.getRow(k);
		XSSFCell cell = Row.getCell(z);
		String cellValue = cell.toString();
		System.out.println(cellValue);
		
		    int RowCount1 = ws1.getLastRowNum()+1;
		    System.out.println("Second Sheet Row Count"+RowCount1);
		    for(int j=2;j<RowCount1;j++)
		    {
		   	int zz=3;
		      XSSFRow Row1 = ws1.getRow(j);
		      XSSFCell cell1 = Row1.getCell(zz);
		      String cellValue1 = cell1.toString();
		      System.out.println(cellValue1);
		   	if(cellValue.equals(cellValue1))
		      		{
		       		WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupID_listbox']"));
		       		List<WebElement> options = test.findElements(By.tagName("li"));
		      			for (WebElement opt : options) 
		      			{
		      				if (opt.getText().equals(cellValue)) 
		      				{
		      					opt.click();
		      					break label;
		      				}
		      			}
		      		}
		      	zz++;
		        }
		    z++;
          }
		if(data3.equalsIgnoreCase("ASIA"))
		{
			driver.findElement(By.xpath("//li[contains(text(),'ASIA')]")).click();
		}else {
			driver.findElement(By.xpath("//li[contains(text(),'AUSTRALIA')]")).click();	
		}
	}
	
	public void operationGroupName(String data4) throws Exception
	{
	
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[9]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		FileInputStream fis = new FileInputStream(new File("D:\\3MCoal\\3MCoal\\ExcelData\\DataExcelImport.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet ws = wb.getSheetAt(10);
		XSSFSheet ws1 = wb.getSheetAt(9);
		int RowCount = ws.getLastRowNum()+1;
		int ColumnCount = ws.getRow(0).getLastCellNum();
		
		label:
		for(int k=2; k<RowCount; k++)
		{
			int z=0;
		XSSFRow Row = ws.getRow(k);
		XSSFCell cell = Row.getCell(z);
		String cellValue = cell.toString();
		System.out.println(cellValue);
		
		    int RowCount1 = ws1.getLastRowNum()+1;
		    System.out.println("Second Sheet Row Count"+RowCount1);
		    for(int j=2;j<RowCount1;j++)
		    {
		   	int zz=3;
		      XSSFRow Row1 = ws1.getRow(j);
		      XSSFCell cell1 = Row1.getCell(zz);
		      String cellValue1 = cell1.toString();
		      System.out.println(cellValue1);
		   	if(cellValue.equals(cellValue1))
		      		{
		       		WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupID_listbox']"));
		       		List<WebElement> options = test.findElements(By.tagName("li"));
		      			for (WebElement opt : options) 
		      			{
		      				if (opt.getText().equals(cellValue)) 
		      				{
		      					opt.click();
		      					break label;
		      				}
		      			}
		      		}
		      	zz++;
		        }
		    z++;
          }
		if(data4.equalsIgnoreCase("Clean coating"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Clean coating')]")).click();
		}else {
			driver.findElement(By.xpath("//li[contains(text(),'Assembly')]")).click();
		}
		Thread.sleep(2000);
		
	}
	
	public void operationTypeName(String data5) throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[10]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		FileInputStream fis = new FileInputStream(new File("D:\\3MCoal\\3MCoal\\ExcelData\\DataExcelImport.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet ws = wb.getSheetAt(11);
		XSSFSheet ws1 = wb.getSheetAt(9);
		int RowCount = ws.getLastRowNum()+1;
		int ColumnCount = ws.getRow(0).getLastCellNum();
		
		label:
		for(int k=2; k<RowCount; k++)
		{
			int z=0;
		XSSFRow Row = ws.getRow(k);
		XSSFCell cell = Row.getCell(z);
		String cellValue = cell.toString();
		System.out.println(cellValue);
		
		    int RowCount1 = ws1.getLastRowNum()+1;
		    System.out.println("Second Sheet Row Count"+RowCount1);
		    for(int j=2;j<RowCount1;j++)
		    {
		   	int zz=4;
		      XSSFRow Row1 = ws1.getRow(j);
		      XSSFCell cell1 = Row1.getCell(zz);
		      String cellValue1 = cell1.toString();
		      System.out.println(cellValue1);
		   	if(cellValue.equals(cellValue1))
		      		{
		       		WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupID_listbox']"));
		       		List<WebElement> options = test.findElements(By.tagName("li"));
		      			for (WebElement opt : options) 
		      			{
		      				if (opt.getText().equals(cellValue)) 
		      				{
		      					opt.click();
		      					break label;
		      				}
		      			}
		      		}
		      	zz++;
		        }
		    z++;
          }
		if(data5.equalsIgnoreCase("Assembly Type"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Assembly Type')]")).click();
		}
		Thread.sleep(2000);
	}
	
	//Need to do
	public void operationDivisionName(String data6) throws InterruptedException, Exception
	{
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[11]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		FileInputStream fis = new FileInputStream(new File("D:\\3MCoal\\3MCoal\\ExcelData\\DataExcelImport.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet ws = wb.getSheetAt(6);
		XSSFSheet ws1 = wb.getSheetAt(7);
		int RowCount = ws.getLastRowNum()+1;
		int ColumnCount = ws.getRow(0).getLastCellNum();
		
		label:
		for(int k=2; k<RowCount; k++)
		{
			int z=0;
		XSSFRow Row = ws.getRow(k);
		XSSFCell cell = Row.getCell(z);
		String cellValue = cell.toString();
		System.out.println(cellValue);
		
		    int RowCount1 = ws1.getLastRowNum()+1;
		    System.out.println("Second Sheet Row Count"+RowCount1);
		    for(int j=2;j<RowCount1;j++)
		    {
		   	int zz=2;
		      XSSFRow Row1 = ws1.getRow(j);
		      XSSFCell cell1 = Row1.getCell(zz);
		      String cellValue1 = cell1.toString();
		      System.out.println(cellValue1);
		   	if(cellValue.equals(cellValue1))
		      		{
		       		WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupID_listbox']"));
		       		List<WebElement> options = test.findElements(By.tagName("li"));
		      			for (WebElement opt : options) 
		      			{
		      				if (opt.getText().equals(cellValue)) 
		      				{
		      					opt.click();
		      					break label;
		      				}
		      			}
		      		}
		      	zz++;
		        }
		    z++;
          }
		if(data6.equalsIgnoreCase("3M Ventures"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'3M Ventures')]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();	
	}
	
	public void operationGroup(String data7) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(5000);
		//Add Button
		driver.findElement(By.xpath("//*[@id='operationGroupGrid']/div[1]/a")).click();	
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='OperationGroupName']")).sendKeys(data7);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='operationGroupGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
	public void operationType(String data8) throws InterruptedException
	{
		//Add Button 
		driver.findElement(By.xpath("//*[@id='operationTypeGrid']/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='OperationTypeName']")).sendKeys(data8);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='operationTypeGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();		
	}
	
	public void workCenterName(String data1) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(2000);
		//Add button		
		driver.findElement(By.xpath("//*[@id='MasterWorkCenterGrid']/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
		Thread.sleep(2000);
	}
	
	public void workCenterSName(String data2) throws InterruptedException
	{
		driver.findElement(By.xpath("//input[@id='ShortName']")).sendKeys(data2);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='MasterWorkCenterGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
	public void unitConversionlevel(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='btnUnitConv']")).click();
		Thread.sleep(2000);
		Select conversionlevel = new Select(driver.findElement(By.xpath("//*[@id='UnitConversionLevelStaticSequenceNumber']")));
		conversionlevel.selectByVisibleText("Global");
	}
	
	public void unitConversionWC(String data2) throws InterruptedException
	{	
		Thread.sleep(3000);
		Select workcenter = new Select(driver.findElement(By.xpath("//*[@id='WorkCenterID']")));
		//Thread.sleep(3000);
		//if(data2.equalsIgnoreCase("Mumbai"))
		//{
		workcenter.selectByVisibleText("Korea");
		//}
	}
	
	public void unitConversionFunit(String data3) throws InterruptedException
	{
		Thread.sleep(3000);
		Select fromunit = new Select(driver.findElement(By.xpath("//*[@id='FromUOMID']")));
		//Thread.sleep(3000);
		//if(data3.equalsIgnoreCase("EACH"))
		//{
		fromunit.selectByVisibleText("EACH");
		//Thread.sleep(3000);
		//}
	}
	
	public void unitConversionTunit(String data4) throws InterruptedException
	{
		Select tounit = new Select(driver.findElement(By.xpath("//*[@id='ToUOMID']")));
		//Thread.sleep(3000);
		//if(data4.equalsIgnoreCase("EACH"))
		//{
		tounit.selectByVisibleText("EACH");
		//}
	}
	
	public void unitConversionCFactor(String data5) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='ConversionFactor']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='ConversionFactor']")).sendKeys("2");
		Thread.sleep(4000);
		//Save
		driver.findElement(By.xpath("//input[@value='Save']")).click();	
	}
	
	public ManufacturingRelationship manufacturingRelationshipmethod() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[contains(text(),'Manufacturing Relationship (MR)')]")).click();
		return new ManufacturingRelationship(driver);
	}
}
