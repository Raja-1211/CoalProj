package adminTestCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.ProductFamilyGroup;
import coalBase.BaseMethods;
import utilis.DataProviderProduct;
import utilis.DataProviderProductFamily;
import utilis.DataProviderProductGroup;
import utilis.Reports;

public class TC_03 extends Reports
{

	/**
	 * This method will fetch the Product Group data from the Excel and pass it to the Product Group fields
	 * @author Raja
	 */
    public WebDriver driver;
	
	@Test
	public void TC_00test() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","D:\\3MCoal\\3MCoal\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-extensions");
		driver = new ChromeDriver();
		driver.get("https://qa-coal.mmm.com");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
	
		driver.findElement(By.xpath("//a[contains(text(),'Product | Family | Group')]")).click();	
		Thread.sleep(3000);		
}
	
	@DataProvider(name="ProductGroup")
	public static Object[][] productGroupData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProductGroup.readProductGroup();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ProductGroup")
	public void TC_01ProductGroupPage(String data1,String data2) throws Exception
	{
	Thread.sleep(2000);
	//test = extent.createTest("Product Group Test");
	ProductFamilyGroup prodgroup = new ProductFamilyGroup(driver);
	prodgroup.productGroupadd();
	prodgroup.productGroupName(data1);
	prodgroup.productGroupUoM(data2);
	}
	
	/**
	 * This method will fetch the Product Family data from the Excel and pass it to the Product Family fields
	 * @author Raja
	 */
	
	@DataProvider(name="ProductFamily")
	public static Object[][] productFamilyData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProductFamily.readProductFamily();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Family data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ProductFamily")
	public void TC_02ProductFamilyPage(String data1,String data2, String data3) throws Exception
	{
		//test = extent.createTest("Product Family Test");
		ProductFamilyGroup prodfamily = new ProductFamilyGroup(driver);
		prodfamily.productFamilyadd();
		prodfamily.productFamilyName(data1);
		prodfamily.productFamilyUoM(data2);
		prodfamily.productFamilyGroup(data3);
		prodfamily.productFamilyselect();
	}
	
	/**
	 * This method will fetch the Product data from the Excel and pass it to the Product fields
	 * @author Raja
	 */
	
	@DataProvider(name="Product")
	public static Object[][] productData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProduct.readProduct();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Product")
	public void TC_03ProductPage(String data1,String data2, String data3, String data4, String data5, String data6, String data7, String data8, String data9, String data10, String data11,String data12,String data13) throws Exception
	{
		//test = extent.createTest("Product Test");
		ProductFamilyGroup productdata = new ProductFamilyGroup(driver);
		productdata.ProductName(data1);
		productdata.ProductShortName(data2);
		productdata.Productdescription(data3);
		productdata.ProductUoM(data4);
		productdata.ProductCurrency(data5);
		productdata.Productfam(data6);
		productdata.ProductCategory(data7);
		productdata.ProductSAP(data8);
		productdata.Productlegacy(data9);
		productdata.ProductOnHandQuantity(data10);
		productdata.ProductStorage(data11);
		productdata.ProductTransportation(data12);
		productdata.ProductTesting(data13);
		productdata.ProductIsPhantom();	
	}

	@Override
	public long takeSnap() {
		// TODO Auto-generated method stub
		return 0;
	}	
}
