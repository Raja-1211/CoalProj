package adminTestCases;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.BaseMaster;
import coalBase.BaseMethods;
import utilis.DataProviderCountry;
import utilis.DataProviderCurrency;
import utilis.DataProviderCustomer;
import utilis.DataProviderDivision;
import utilis.DataProviderRegion;
import utilis.DataProviderUoM;
import utilis.Reports;

public class TC_02 extends Reports
{

	/**
	 * This method will fetch the Customer data from the Excel and pass it to the Customer fields
	 * @author Raja
	 * @return 
	 * @throws InterruptedException 
	 */

	public WebDriver driver;
	
	@Test
	public void TC_00testing() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","D:\\3MCoal\\3MCoal\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-extensions");
		driver = new ChromeDriver();
		driver.get("https://qa-coal.mmm.com");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Base Master')]")).click();		
     }
	
	@DataProvider(name="Customer")
	public static Object[][] baseCustomer() throws Exception 
	{
		Object[][] arrayObject = DataProviderCustomer.readCustomerdata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Customer data to the Customer fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Customer")
	public void TC_01customerPage(String data1, String data2, String data3) throws Exception
	{
		//test = extent.createTest("Customer Test");
		Thread.sleep(4000);
		BaseMaster test = new BaseMaster(driver);
		test.createCustomername(data1);
		test.createCustomersnname(data2);
		test.createCustomerCategory(data3);	
	}
	
	/**
	 * This method will fetch the Currency data from the Excel and pass it to the Currency fields
	 * @author Raja
	 */
	
	@DataProvider(name="Currency")
	public static Object[][] baseCurrency() throws Exception 
	{
		Object[][] arrayObject = DataProviderCurrency.readCurrencydata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Currency data to the Currency fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Currency")
	public void TC_02currencyPage(String data1, String data2) throws Exception
	{
		//test = extent.createTest("Currency Test");
		BaseMaster currency = new BaseMaster(driver);
		currency.createCurrencyName(data1);
		currency.createCurrencySName(data2);
	}
	
	/**
	 * This method will fetch the Region data from the Excel and pass it to the Region fields
	 * @author Raja
	 */
	
	@DataProvider(name="Region")
	public static Object[][] baseRegion() throws Exception 
	{
		Object[][] arrayObject = DataProviderRegion.readRegiondata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Region data to the Region fields 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Region")
	public void TC_03regionPage(String data1, String data2) throws Exception
	{
		//test = extent.createTest("Region Test");
		BaseMaster region = new BaseMaster(driver);
		region.createRegionName(data1);
		region.createRegionSName(data2);
	}
	
	/**
	 * This method will fetch the Country data from the Excel and pass it to the Country fields
	 * @author Raja
	 */
	
	@DataProvider(name="Country")
	public static Object[][] baseCountry() throws Exception 
	{
		Object[][] arrayObject = DataProviderCountry.readCountrydata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Country data to the Country fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Country")
	public void TC_04countryPage(String data1, String data2,String data3, String data4) throws Exception
	{
		//test = extent.createTest("Country Test");
		BaseMaster country = new BaseMaster(driver);
		country.createCountryName(data1);
		country.createCountrySName(data2);
		country.createCountryLatitude(data3);
		country.createCountryLongitude(data4);
	}
	
	
	
	@DataProvider(name="Division")
	public static Object[][] baseDivision() throws Exception 
	{
		Object[][] arrayObject = DataProviderDivision.readDivisiondata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Login data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Division")
	public void TC_05Division(String data1,String data2,String data3) throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)", "");
		BaseMaster division = new BaseMaster(driver);
		division.DivisionCustomer(data1);
		division.DivisionProduct(data2);
		division.DivisionWorkCenter(data3);
		
	}
	
	@DataProvider(name="UoM")
	public static Object[][] baseUoM() throws Exception 
	{
		Object[][] arrayObject = DataProviderUoM.readUoMdata();
		return arrayObject;
	}
	
	@Test(dataProvider="UoM")
	public void TC_06UoM(String data1,String data2,String data3)throws Exception
	{
		//test = extent.createTest("Uom Test");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)", "");
		BaseMaster uom = new BaseMaster(driver);
		uom.createUoMName(data1);
		uom.createUoMCode(data2);
		uom.createUoMDescription(data3);
	}

	@Override
	public long takeSnap() {
		return 0;
	}
}
