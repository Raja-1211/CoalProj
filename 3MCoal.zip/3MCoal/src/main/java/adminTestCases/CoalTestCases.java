package adminTestCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.AdminPage;
import coalAdminPages.BaseMaster;
import coalAdminPages.CreateModel;
import coalAdminPages.LoginPage;
import coalAdminPages.ManufacturingRelationship;
import coalAdminPages.OperationWorkCenter;
import coalAdminPages.ProductFamilyGroup;
import coalAdminPages.Routing;
import coalBase.BaseMethods;
import utilis.DPCreateModel;
import utilis.DPMR;
import utilis.DPMRCO;
import utilis.DPOperation;
import utilis.DPOperationGroup;
import utilis.DPOperationType;
import utilis.DPRouting;
import utilis.DPUnitConverison;
import utilis.DPWorkCenter;
import utilis.DataProviderCountry;
import utilis.DataProviderCurrency;
import utilis.DataProviderCustomer;
import utilis.DataProviderDivision;
import utilis.DataProviderLogin;
import utilis.DataProviderProduct;
import utilis.DataProviderProductFamily;
import utilis.DataProviderProductGroup;
import utilis.DataProviderRegion;
import utilis.DataProviderUoM;

public class CoalTestCases extends BaseMethods
{

	@Test
	public void TC_01startapp()
	{
		    System.setProperty("webdriver.chrome.driver","D:\\3MCoal\\3MCoal\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-extensions");
			driver = new ChromeDriver();
			driver.get("https://qa-coal.mmm.com");
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.manage().window().maximize();
	}
	
	/**
	 * This method will pass the Login data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@DataProvider(name="Login")
	public static Object[][] loginCoal() throws Exception 
	{
		Object[][] arrayObject = DataProviderLogin.readInputlogin();
		return arrayObject;
	}
	
	@Test(dataProvider="Login")
	public void TC_02LoginPage(String usernamedata, String passworddata) throws Exception
	{
		
		//test = extent.createTest("Login Page Test");
		LoginPage coallogin = new LoginPage(driver);		
		coallogin.UserName(usernamedata);
		coallogin.Password(passworddata);
		coallogin.clickLogIn();
		AdminPage adminpage = new AdminPage(driver);
		adminpage.adminmainpage();
		adminpage.adminBaseMaster();
	}
	
	@DataProvider(name="Customer")
	public static Object[][] baseCustomer() throws Exception 
	{
		Object[][] arrayObject = DataProviderCustomer.readCustomerdata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Customer data to the Customer fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Customer")
	public void TC_03customerPage(String data1, String data2, String data3) throws Exception
	{
		//test = extent.createTest("Customer Test");
		Thread.sleep(4000);
		BaseMaster test = new BaseMaster(driver);
		test.createCustomername(data1);
		test.createCustomersnname(data2);
		test.createCustomerCategory(data3);	
	}
	
	/**
	 * This method will fetch the Currency data from the Excel and pass it to the Currency fields
	 * @author Raja
	 */
	
	@DataProvider(name="Currency")
	public static Object[][] baseCurrency() throws Exception 
	{
		Object[][] arrayObject = DataProviderCurrency.readCurrencydata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Currency data to the Currency fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Currency")
	public void TC_04currencyPage(String data1, String data2) throws Exception
	{
		//test = extent.createTest("Currency Test");
		BaseMaster currency = new BaseMaster(driver);
		currency.createCurrencyName(data1);
		currency.createCurrencySName(data2);
	}
	
	/**
	 * This method will fetch the Region data from the Excel and pass it to the Region fields
	 * @author Raja
	 */
	
	@DataProvider(name="Region")
	public static Object[][] baseRegion() throws Exception 
	{
		Object[][] arrayObject = DataProviderRegion.readRegiondata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Region data to the Region fields 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Region")
	public void TC_05regionPage(String data1, String data2) throws Exception
	{
		//test = extent.createTest("Region Test");
		BaseMaster region = new BaseMaster(driver);
		region.createRegionName(data1);
		region.createRegionSName(data2);
	}
	
	/**
	 * This method will fetch the Country data from the Excel and pass it to the Country fields
	 * @author Raja
	 */
	
	@DataProvider(name="Country")
	public static Object[][] baseCountry() throws Exception 
	{
		Object[][] arrayObject = DataProviderCountry.readCountrydata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Country data to the Country fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Country")
	public void TC_06countryPage(String data1, String data2,String data3, String data4) throws Exception
	{
		//test = extent.createTest("Country Test");
		BaseMaster country = new BaseMaster(driver);
		country.createCountryName(data1);
		country.createCountrySName(data2);
		country.createCountryLatitude(data3);
		country.createCountryLongitude(data4);
	}
	
	
	
	/*@DataProvider(name="Division")
	public static Object[][] baseDivision() throws Exception 
	{
		Object[][] arrayObject = DataProviderDivision.readDivisiondata();
		return arrayObject;
	}
	
	*//**
	 * This method will pass the Login data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 *//*
	
	@Test(dataProvider="Division")
	public void TC_07Division(String data1,String data2,String data3) throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)", "");
		BaseMaster division = new BaseMaster(driver);
		division.DivisionCustomer(data1);
		division.DivisionProduct(data2);
		division.DivisionWorkCenter(data3);
		
	}*/
	
	@DataProvider(name="UoM")
	public static Object[][] baseUoM() throws Exception 
	{
		Object[][] arrayObject = DataProviderUoM.readUoMdata();
		return arrayObject;
	}
	
	@Test(dataProvider="UoM")
	public void TC_08UoM(String data1,String data2,String data3)throws Exception
	{
		//test = extent.createTest("Uom Test");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)", "");
		BaseMaster uom = new BaseMaster(driver);
		uom.createUoMName(data1);
		uom.createUoMCode(data2);
		uom.createUoMDescription(data3);
	}	
	
	@DataProvider(name="ProductGroup")
	public static Object[][] productGroupData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProductGroup.readProductGroup();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ProductGroup")
	public void TC_09ProductGroupPage(String data1,String data2) throws Exception
	{
	Thread.sleep(2000);
	//test = extent.createTest("Product Group Test");
	ProductFamilyGroup prodgroup = new ProductFamilyGroup(driver);
	prodgroup.productGroupadd();
	prodgroup.productGroupName(data1);
	prodgroup.productGroupUoM(data2);
	}
	
	/**
	 * This method will fetch the Product Family data from the Excel and pass it to the Product Family fields
	 * @author Raja
	 */
	
	@DataProvider(name="ProductFamily")
	public static Object[][] productFamilyData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProductFamily.readProductFamily();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Family data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ProductFamily")
	public void TC_10ProductFamilyPage(String data1,String data2, String data3) throws Exception
	{
		//test = extent.createTest("Product Family Test");
		ProductFamilyGroup prodfamily = new ProductFamilyGroup(driver);
		prodfamily.productFamilyadd();
		prodfamily.productFamilyName(data1);
		prodfamily.productFamilyUoM(data2);
		prodfamily.productFamilyGroup(data3);
		prodfamily.productFamilyselect();
	}
	
	/**
	 * This method will fetch the Product data from the Excel and pass it to the Product fields
	 * @author Raja
	 */
	
	@DataProvider(name="Product")
	public static Object[][] productData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProduct.readProduct();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Product")
	public void TC_11ProductPage(String data1,String data2, String data3, String data4, String data5, String data6, String data7, String data8, String data9, String data10, String data11,String data12,String data13) throws Exception
	{
		//test = extent.createTest("Product Test");
		ProductFamilyGroup productdata = new ProductFamilyGroup(driver);
		productdata.ProductName(data1);
		productdata.ProductShortName(data2);
		productdata.Productdescription(data3);
		productdata.ProductUoM(data4);
		productdata.ProductCurrency(data5);
		productdata.Productfam(data6);
		productdata.ProductCategory(data7);
		productdata.ProductSAP(data8);
		productdata.Productlegacy(data9);
		productdata.ProductOnHandQuantity(data10);
		productdata.ProductStorage(data11);
		productdata.ProductTransportation(data12);
		productdata.ProductTesting(data13);
		productdata.ProductIsPhantom();	
	}
	
	@DataProvider(name="ReadOperationType")
	public static Object[][] readOperationType() throws Exception 
	{
		Object[][] arrayObject = DPOperationType.readOperationType();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationType")
	public void TC_12ReadOperationTypetc(String data8) throws Exception
	{
		//test = extent.createTest("Operation Type Test");
		OperationWorkCenter optype = new OperationWorkCenter(driver);
		optype.operationType(data8);
	}
	
	
	@DataProvider(name="ReadOperation")
	public static Object[][] readOperation() throws Exception 
	{
		Object[][] arrayObject = DPOperation.readOperation();
		return arrayObject;
	}

	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationGroup")
	public void TC_13readOperationGrouptc(String data7) throws Exception
	{
		//test = extent.createTest("Operation Group Test");
		OperationWorkCenter opg = new OperationWorkCenter(driver);
		opg.operationGroup(data7);
	}
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@DataProvider(name="ReadOperationGroup")
	public static Object[][] readOperationGroup() throws Exception 
	{
		Object[][] arrayObject = DPOperationGroup.readOperationGroup();
		return arrayObject;
	}
	
	@Test(dataProvider="ReadOperation")
	public void TC_14readOperationtc(String data1,String data2,String data3,String data4,String data5,String data6) throws Exception
	{
	//test = extent.createTest("Operation Test");
	Thread.sleep(2000);
	OperationWorkCenter operationtest = new OperationWorkCenter(driver);
	operationtest.operationName(data1);
	operationtest.operationSName(data2);
	operationtest.operationRegion(data3);
	operationtest.operationGroupName(data4);
	operationtest.operationTypeName(data5);
	operationtest.operationDivisionName(data6);
	}
	
	@DataProvider(name="ReadOperationWC")
	public static Object[][] readOperationWc() throws Exception 
	{
		Object[][] arrayObject = DPWorkCenter.readOperationWC();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationWC")
	public void TC_15readOperationWctc(String data9,String data10) throws Exception
	{
		//test = extent.createTest("Operation Work Center Test");
		OperationWorkCenter opwc = new OperationWorkCenter(driver);
		opwc.workCenterName(data9);
		opwc.workCenterSName(data10);
	}
	
	@DataProvider(name="ReadOperationUnitConc")
	public static Object[][] readOperationUnitConversion() throws Exception 
	{
		Object[][] arrayObject = DPUnitConverison.readOperationuc();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationUnitConc")
	public void TC_16readOperationUnitConv(String data11,String data12,String data13,String data14, String data15) throws Exception
	{
		//test = extent.createTest("Operation UnitConversion Test");
		OperationWorkCenter opuc = new OperationWorkCenter(driver);
		opuc.unitConversionlevel(data11);
		opuc.unitConversionWC(data12);
		opuc.unitConversionFunit(data13);
		opuc.unitConversionTunit(data14);
		opuc.unitConversionCFactor(data15);		
	}

	@DataProvider(name="ManufacturingRelationship")
	public static Object[][] readMR() throws Exception 
	{
		Object[][] arrayObject = DPMR.readOperationMR();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ManufacturingRelationship")
	public void TC_17ReadMRTC(String data1,String data2,String data3) throws Exception
	{
	Thread.sleep(2000);
	//test = extent.createTest("Manufacturing Test");
	ManufacturingRelationship manufrel = new ManufacturingRelationship(driver);
	manufrel.manufacturingRelationshipadd();
	//manufrel.productcheckbox();
	manufrel.manufacturingRelationship(data1);
	manufrel.MROperations(data2);
	manufrel.autoComponent(data3);
	}
	
	@DataProvider(name="ManufacturingRelationshipCO")
	public static Object[][] readMRCO() throws Exception 
	{
		Object[][] arrayObject = DPMRCO.readOperationMRCO();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ManufacturingRelationshipCO")
	public void TC_18readMRTCCO(String data1,String data2,String data3) throws Exception
	{
	Thread.sleep(2000);
	//test = extent.createTest("Manufacturing Componet/Operation Test");
	ManufacturingRelationship manufrel = new ManufacturingRelationship(driver);
	manufrel.manufacturingRelationshipadd();
	//manufrel.productcheckbox();
	manufrel.manufacturingRelationship(data1);
	manufrel.MROperations(data2);
	manufrel.autoComponent(data3);
	}

	@DataProvider(name="Routing")
	public static Object[][] readRouting() throws Exception 
	{
		Object[][] arrayObject = DPRouting.readRouting();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Routing")
	public void TC_19readRoutingTC(String data1,String data2) throws Exception
	{
	//test = extent.createTest("Routing Test");
	Thread.sleep(2000);
	Routing route = new Routing(driver);
	route.routingAddbtn();
	route.routeName(data1);
	route.routeProduct(data2);
	//route.routeStatus(data3);
	route.expandAll();
	//route.expandAll();	
	//route.isTemplate(data4);
	//route.needFocusFactory(data5);
	//route.saveButton();
	}
	
	@DataProvider(name="CreateModel")
	public static Object[][] readCreateMod() throws Exception 
	{
		Object[][] arrayObject = DPCreateModel.readCreateModel();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="CreateModel")
	public void TC_20readCreationModTC(String data1,String data2,String data3,String data4, String data5, String data6) throws Exception
	{
	//test = extent.createTest("Create Model Test");
	CreateModel newmodel = new CreateModel(driver);
	Thread.sleep(2000);
	newmodel.CreateNewModelbutton();
	newmodel.CreateNewModelName(data1);
	newmodel.CreateNewModelDescription(data2);
	newmodel.CreateNewModelUoM();
	newmodel.CreateNewModelDivision();
	newmodel.CreateNewModelPlanningMethod(data3);
	newmodel.CreateNewModelNeedFocusFactory(data4);
	newmodel.CreateNewModelPeriodType(data5);
	newmodel.CreateNewModelPeriods(data6);	
	}



}
