package adminTestCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import coalAdminPages.AdminPage;
import coalAdminPages.LoginPage;
import coalBase.BaseMethods;
import utilis.DataProviderLogin;
import utilis.Reports;

/**
 * This class contains the Test Cases for the "Coal-Login Page"
 * @author Raja
 */

public class TC_01 extends Reports
{
	/**
	 * This method will launch the Chrome or IE browser
	 * This method will load the specified browser
	 * @author Raja
	 */
	
	public WebDriver driver;
	
	@Test
	public void TC_01startapp()
	{
		    System.setProperty("webdriver.chrome.driver","D:\\3MCoal\\3MCoal\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-extensions");
			driver = new ChromeDriver();
			driver.get("https://qa-coal.mmm.com");
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.manage().window().maximize();
	}

	/**
	 * This method will fetch the Login data from the Excel and pass it to the Login Page method
	 * @author Raja
	 */
	
	
	/**
	 * This method will pass the Login data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Login")
	public void TC_02LoginPage(String usernamedata, String passworddata) throws Exception
	{
		
		//test = extent.createTest("Login Page Test");
		LoginPage coallogin = new LoginPage(driver);		
		coallogin.UserName(usernamedata);
		coallogin.Password(passworddata);
		coallogin.clickLogIn();
		AdminPage adminpage = new AdminPage(driver);
		adminpage.adminmainpage();
		adminpage.adminBaseMaster();
	}

	@Override
	public long takeSnap() 
	{
		return 0;
	}
}	
	
