package coalPagesMyModels;

import coalBase.BaseMethods;

public class CollaborateShare extends BaseMethods
{

	public void cloneCoal()
	{
		
	}
	
	public void migrateModel()
	{
		
	}
	
	public void share()
	{
		
	}
	
	public void createScenario()
	{
		
	}
			
}
